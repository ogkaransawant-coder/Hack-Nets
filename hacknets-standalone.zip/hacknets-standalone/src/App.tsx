import { useEffect } from 'react';
import { ArrowDown, ArrowUpRight, Play, Sparkles } from 'lucide-react';
import './site.css';

// Change this to your actual inquiry inbox before publishing.
const CONTACT_EMAIL = 'hello@hacknets.in';
const contactHref = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent('Let’s make something worth watching')}`;

function Home() {
  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>('.reveal');
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion || !('IntersectionObserver' in window)) {
      nodes.forEach((node) => node.classList.add('is-visible'));
      return;
    }
    document.documentElement.classList.add('motion-ready');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
    nodes.forEach((node) => observer.observe(node));
    return () => {
      observer.disconnect();
      document.documentElement.classList.remove('motion-ready');
    };
  }, []);

  return (
    <main className="hn">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className="wrap topbar">
        <a className="brand" href="#top" aria-label="Hack Nets home" data-testid="link-home">
          <span className="brand-mark" aria-hidden="true">h</span><span>hack nets</span>
        </a>
        <nav className="navlinks" aria-label="Main navigation">
          <a href="#what-we-do" data-testid="link-services">What we do</a>
          <a href="#how-we-work" data-testid="link-process">How we work</a>
          <a href="#ideas" data-testid="link-ideas">Ideas</a>
          <a className="nav-cta" href={contactHref} data-testid="link-header-contact">Let’s talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <div id="main-content">
        <section className="wrap hero" id="top" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow mono"><span className="eyebrow-dot" /> Independent content studio · Strategy × creative</div>
            <h1 id="hero-title" className="display">Make good<br />things <span className="outline">unmissable.</span></h1>
            <p className="hero-lede">Hack Nets is a content marketing agency helping ambitious brands find their voice, build a sharper strategy, and make stories worth stopping for.</p>
            <div className="hero-actions">
              <a className="button" href={contactHref} data-testid="link-hero-contact">Start a conversation <ArrowUpRight size={16} /></a>
              <a className="text-link" href="#what-we-do" data-testid="link-explore-services">See what we make <ArrowDown size={15} /></a>
            </div>
          </div>
          <div className="hero-art" aria-label="Abstract Hack Nets creative studio artwork">
            <div className="orbit" />
            <div className="hero-sun"><div className="sun-inner"><div className="sun-word">Ideas<br />in motion<small>HACK NETS / STUDIO</small></div></div></div>
            <div className="float-card card-top"><strong>Scroll-stopping<br />starts here.</strong><span>STRATEGY × CREATIVE</span></div>
            <div className="float-card card-bottom"><strong>Less noise.<br />More meaning.</strong><span>MADE FOR THE FEED</span></div>
            <div className="scribble" aria-hidden="true">*</div>
          </div>
          <div className="hero-caption mono"><span>Strategy with a point of view</span><span>01 — 06 / Discover</span></div>
        </section>

        <div className="ticker" aria-label="Hack Nets capabilities">
          <div className="ticker-track">
            <span>THINK SHARPER</span><b>+</b><span>MAKE WITH PURPOSE</span><b>+</b><span>SHOW UP DIFFERENT</span><b>+</b><span>THINK SHARPER</span><b>+</b><span>MAKE WITH PURPOSE</span>
          </div>
        </div>

        <section className="wrap section" aria-labelledby="intro-title">
          <div className="intro-grid">
            <div className="reveal">
              <div className="section-kicker mono">01 / The short version</div>
              <h2 id="intro-title" className="section-title display">The internet has enough content. It needs <span style={{ color: '#6650e8' }}>better ideas.</span></h2>
              <p className="section-intro">We connect the dots between what your brand stands for and what people actually want to watch, read, save, and share.</p>
            </div>
            <div className="intro-side reveal delay-1">
              <p>Not content for content’s sake. Not a calendar full of filler. We help you get clear on the story, then make that story work across the places your audience spends time.</p>
              <p>Close collaboration, useful feedback, and the people shaping the ideas involved in the work.</p>
            </div>
          </div>
        </section>

        <section className="section services" id="what-we-do" aria-labelledby="services-title">
          <div className="wrap">
            <div className="services-head reveal">
              <div>
                <div className="section-kicker mono">02 / What we do</div>
                <h2 id="services-title" className="section-title display">From first thought<br />to final frame.</h2>
              </div>
              <p className="section-intro">Bring us one sharp brief or the whole messy challenge. We’ll find the right mix.</p>
            </div>
            <div className="service-list">
              {[
                ['01', 'Content strategy', 'Positioning, audience truths, content pillars, and a clear plan for what to say—and why it matters.'],
                ['02', 'Social-first content', 'Distinctive concepts and platform-native posts built to earn attention, not just fill a slot.'],
                ['03', 'Social management', 'A thoughtful rhythm for your channels: planning, publishing, community cues, and iteration.'],
                ['04', 'Video & YouTube', 'From punchy short-form to a series with legs—strong hooks, considered stories, better packaging.'],
                ['05', 'Design & visual systems', 'Flexible graphic design that makes your ideas instantly recognisable across every touchpoint.'],
                ['06', 'Paid promotion', 'Creative-led campaign thinking and paid distribution designed to give good work a useful push.'],
                ['07', 'Consulting & workshops', 'A fresh set of eyes, a working session, or a partner to help your team make the next call.'],
              ].map(([number, title, description]) => (
                <article className="service-row reveal" key={number} data-testid={`service-${number}`}>
                  <span className="service-no">{number}</span><h3>{title}</h3><p>{description}</p><ArrowUpRight className="service-arrow" size={19} aria-hidden="true" />
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section approach" id="how-we-work" aria-labelledby="approach-title">
          <div className="wrap">
            <div className="reveal">
              <div className="section-kicker mono">03 / A good way to work</div>
              <h2 id="approach-title" className="section-title display">Clear heads.<br />Curious hands.</h2>
              <p className="section-intro">A practical, collaborative process that leaves room for the unexpected—and keeps the work pointed at a real goal.</p>
            </div>
            <div className="steps">
              {[
                ['01', 'Get curious', 'We listen closely, ask better questions, and get under the skin of your brand.'],
                ['02', 'Find the angle', 'We turn context into a clear strategy and a creative direction worth backing.'],
                ['03', 'Make the thing', 'We build, test, refine, and sweat the details together with your team.'],
                ['04', 'Keep learning', 'We look at what resonates, take the signal seriously, and make the next round smarter.'],
              ].map(([number, title, copy], i) => (
                <article className={`step reveal ${i % 2 ? 'delay-1' : ''}`} key={number}>
                  <span className="step-num">{number} / 04</span><h3>{title}</h3><p>{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section work" id="ideas" aria-labelledby="ideas-title">
          <div className="wrap">
            <div className="work-top reveal">
              <div>
                <div className="section-kicker mono">04 / The idea playground</div>
                <h2 id="ideas-title" className="section-title display">A peek at how<br />we think.</h2>
              </div>
              <span className="concept-label">Concept directions · illustrative, not client work</span>
            </div>
            <div className="concepts">
              <article className="concept-card concept-large reveal" data-testid="concept-card-one">
                <span className="mono">CONCEPT 01 — CULTURE / COMMUNITY</span>
                <div className="visual-sticker" aria-hidden="true"><span>Make<br />room for<br />the good<br />stuff.</span></div>
                <h3 className="concept-title">A little less<br />broadcast.<br />A lot more<br />belonging.</h3>
                <div className="concept-footer"><span>Social series thought starter</span><Play size={15} /></div>
              </article>
              <article className="concept-card concept-small reveal delay-1" data-testid="concept-card-two">
                <span className="mono">CONCEPT 02 — VIDEO / STORY</span>
                <div className="visual-sticker" aria-hidden="true"><span>Wait—<br />there’s a<br />story here.</span></div>
                <h3 className="concept-title">The detail<br />everyone<br />scrolls past.</h3>
                <div className="concept-footer"><span>Short-form series thought starter<Sparkles size={14} /></span><ArrowUpRight size={16} /></div>
              </article>
            </div>
          </div>
        </section>

        <section className="proof" aria-labelledby="belief-title">
          <div className="wrap proof-wrap">
            <div className="reveal">
              <div className="section-kicker mono">05 / What we believe</div>
              <h2 id="belief-title" className="proof-quote">Good content isn’t louder. It’s <em>more you</em>, in the right place, at the right time.</h2>
            </div>
            <aside className="proof-note reveal delay-1">
              <span className="mono">A note on our work</span>
              <h3>We’re new. We won’t dress that up.</h3>
              <p>Hack Nets is building its first body of work. The examples on this page are concept directions—not client campaigns. We’d rather show you how we think than borrow someone else’s proof. If that sounds like your kind of honest, let’s talk.</p>
            </aside>
          </div>
        </section>

        <section className="section faq" aria-labelledby="faq-title">
          <div className="wrap faq-grid">
            <div className="reveal">
              <div className="section-kicker mono">06 / Good questions</div>
              <h2 id="faq-title" className="section-title display">Before we<br />get into it.</h2>
              <p className="section-intro">If your question isn’t here, send it our way. We’re good with a direct question.</p>
            </div>
            <div className="faq-list reveal delay-1">
              <details className="faq-item"><summary>Who do you work with?</summary><p>Founders and marketing teams who want a clearer content point of view, stronger creative, or a thoughtful partner to help make it happen. We’re open to different industries and challenges.</p></details>
              <details className="faq-item"><summary>Can you work with our in-house team?</summary><p>Absolutely. We can lead a project, plug into an existing team, or help your people build the confidence and systems to do more themselves.</p></details>
              <details className="faq-item"><summary>What does working together look like?</summary><p>It depends on what you need: a focused strategy sprint, a one-off creative project, ongoing social support, or a workshop. We’ll shape a sensible scope after an initial conversation.</p></details>
              <details className="faq-item"><summary>Do you have a portfolio to share?</summary><p>We’re at the beginning of the Hack Nets journey, so we don’t have client case studies to share yet. The idea cards above are clearly labelled concepts that show a little of our creative approach.</p></details>
              <details className="faq-item"><summary>How do we start?</summary><p>Send a note with a little about your brand and what you’re trying to figure out. No polished brief required—we can start with a conversation.</p></details>
            </div>
          </div>
        </section>

        <footer className="contact" id="contact">
          <div className="wrap">
            <div className="contact-inner reveal">
              <div>
                <div className="section-kicker mono">07 / Your move</div>
                <h2 className="display">Got a good<br />one in mind?</h2>
                <p>Tell us what you’re building, what’s not clicking, or what you can’t stop thinking about. We’ll take it from there.</p>
              </div>
              <a className="button contact-button" href={contactHref} data-testid="link-contact-email">Write us a note <ArrowUpRight size={16} /></a>
            </div>
            <div className="footer">
              <a className="brand" href="#top"><span className="brand-mark" aria-hidden="true">h</span><span>hack nets</span></a>
              <span className="footer-note">Independent minds. Internet-native ideas.</span>
              <div className="footer-links"><a href="#what-we-do">Services</a><a href="#how-we-work">Approach</a><a href={contactHref}>Email us</a></div>
              <span className="footer-note">© {new Date().getFullYear()} Hack Nets</span>
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}

export default Home;
