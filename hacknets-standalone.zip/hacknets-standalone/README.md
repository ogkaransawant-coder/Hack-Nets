# Hack Nets website

An independent, editable React + Vite copy of the Hack Nets marketing website. It does not depend on the original Replit monorepo or its API server.

## Run locally

1. Install Node.js 20.19+ (or 22.12+).
2. Unzip this folder and open a terminal in `hacknets-standalone`.
3. Run `npm install`.
4. Run `npm run dev`, then open the local URL Vite prints.

## Build for hosting

- `npm run build` creates a production site in `dist/`.
- `npm run preview` previews that production build locally.

## Before publishing

- In `src/App.tsx`, update `CONTACT_EMAIL` to the inbox you want inquiries sent to.
- The SEO canonical URL in `index.html` currently points to `https://hacknets.in/`. Change it if the site will use another domain.
- `src/site.css` contains the styling and animations, including reduced-motion support.

The custom typefaces are loaded from Google Fonts when a visitor has an internet connection; system font fallbacks are included.
